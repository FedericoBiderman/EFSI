
let positivo=true;
/*Mostrar la mayor nota*/
function MostrarMayorNota() {

    var notas = [parseFloat(document.getElementById('NotaM').value),
    parseFloat(document.getElementById('NotaL').value),
    parseFloat(document.getElementById('NotaE').value)];

    var mayor = Math.max.apply(null, notas);

    var materiaMayor = "";

    if (notas[0] == mayor) {
        materiaMayor += "Matemática";
    }

    if (notas[1] == mayor) {
        if (materiaMayor != "") {
            materiaMayor += ", Lengua";
        } else {
            materiaMayor += "Lengua";
        }
    }

    if (notas[2] == mayor) {
        if (materiaMayor != "") {
            materiaMayor += ", EFSI";
        } else {
            materiaMayor += "EFSI";
        }
    }

    document.getElementById("Mayor nota").innerHTML = " la mayor nota es: " + materiaMayor;
    document.getElementById("Mayor nota").style.color = "blue";

}

/*Calcular Promedio de Notas*/
function CalcularPromedio() {
    var mate = document.getElementById('NotaM');
    var lengua = document.getElementById('NotaL');
    var efsi = document.getElementById('NotaE');
    var pro = (parseFloat(mate.value) + parseFloat(lengua.value) + parseFloat(efsi.value)) / 3;
    document.getElementById("promedio").innerHTML = pro;
    if (pro >= 6) {
        document.getElementById("promedio").style.color = "green";
    } else {
        document.getElementById("promedio").style.color = "red";
    }
}

/*Validar nota*/
function validateNota(id){
    var materias = document.forms["Formulario"][id].value;
     
    if (materias<1 || materias>10)
    {
        document.getElementById(id).style.color="red";   
        alert("datos incorrectos");
        return false;
    }
    if (materias>1 || materias<10)
    {
        document.getElementById(id).style.color="green";   
        return true;
    }
}
